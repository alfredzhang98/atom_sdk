# __init__.py
from .encryption_tool import ReversibleEncryptionTools
from .encryption_tool import IrreversibleEncryptionTools
AES = ReversibleEncryptionTools.AES
Blowfish = ReversibleEncryptionTools.Blowfish
ECC = ReversibleEncryptionTools.ECC
RSA = ReversibleEncryptionTools.RSA
TripleDES = ReversibleEncryptionTools.TripleDES
Hash = IrreversibleEncryptionTools.Hash

__version__ = '0.0.1'
__all__ = ['ReversibleEncryptionTools', 'IrreversibleEncryptionTools', 'AES', 'Blowfish', 'ECC', 'RSA', 'TripleDES', 'Hash']